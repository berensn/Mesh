/*
  Creates a service to retrieve data from json files.
*/

import { Injectable } from '@angular/core';
import { Article } from './article';
import { Infocast } from './infocast';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class JsonService {

  // Constructors
  constructor(private http: HttpClient) { }

  // Methods
  getArticles(_jsonUrl: string): Observable<Article[]>{
    return this.http.get<Article[]>(_jsonUrl);      
  }

  getInfocast(_jsonUrl: string): Observable<Infocast[]>{
    return this.http.get<Infocast[]>(_jsonUrl);
  }
}