import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plexus',
  templateUrl: './plexus.component.html',
  styleUrls: ['./plexus.component.scss']
})
export class PlexusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
