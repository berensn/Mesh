import { ElementRef } from '@angular/core';
export interface Transfer{
    page: [
        {
            pageNum: number,
            subStart: number,
            subEnd: number
        }   
    ];
    content: string;
    contentBox: ElementRef;
}